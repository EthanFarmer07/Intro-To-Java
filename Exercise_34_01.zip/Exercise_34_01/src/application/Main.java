package application;
	
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.*;


public class Main extends Application 
{
	// Create the text fields to enter information. 
	private TextField tfID = new TextField();
	private TextField tfLName = new TextField();
	private TextField tfFName = new TextField();
	private TextField tfMInital = new TextField();
	private TextField tfAddress = new TextField();
	private TextField tfCity = new TextField();
	private TextField tfState = new TextField();
	private TextField tfPhone = new TextField();
	
	// Create the label for the database status.
	private Label lblStatus = new Label();
	
	// Create the button for updating the information to the table.
	private Button btView = new Button("View"); // This button displays a record with a specified ID.
	private Button btInsert = new Button("Insert"); // This button inserts a new record.
	private Button btUpdate = new Button("Update"); // This button updates the record for the specified ID.
	private Button btClear = new Button("Clear"); // This button clears all the text fields.
	
	// The Statement for processing queries.
	private Statement stmt;
	
	@Override
	public void start(Stage primaryStage) throws SQLException, ClassNotFoundException
	{
		try 
		{
			// Create the vertical box to show the GUI.
			VBox vBox = new VBox(5);
			
		    // Create all the horizontal boxes to show the GUI.
		    HBox hBox1 = new HBox(5);
		    hBox1.getChildren().addAll(new Label("ID:"), tfID);
		    
		    HBox hBox2 = new HBox(5);
		    hBox2.getChildren().addAll(new Label("Last Name:"), tfLName,new Label("First Name:"), tfFName, new Label("MI:"), tfMInital);
		    tfLName.setPrefColumnCount(8);
		    tfFName.setPrefColumnCount(8);
		    tfMInital.setPrefColumnCount(1);

		    HBox hBox3 = new HBox(5);
		    hBox3.getChildren().addAll(new Label("Address:"), tfAddress);
		    
		    HBox hBox4 = new HBox(5);
		    hBox4.getChildren().addAll(new Label("City:"), tfCity,new Label("State:"), tfState);
		    
		    HBox hBox5 = new HBox(5);
		    hBox5.getChildren().addAll(new Label("Telephone:"), tfPhone);
		 
		    vBox.getChildren().addAll(hBox1, hBox2, hBox3, hBox4, hBox5);
		    
		    HBox hBox = new HBox(5);
		    hBox.getChildren().addAll(btView, btInsert, btUpdate, btClear);
		    hBox.setAlignment(Pos.CENTER);
		    
		    // Create the border pane for the GUI.
		    BorderPane pane = new BorderPane();
		    pane.setTop(lblStatus);
		    pane.setCenter(vBox);
		    pane.setBottom(hBox);
			
			// Create a scene and place it in the stage. 
			Scene scene = new Scene(pane);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Exercise_34_01"); // Set the stage title.
			primaryStage.setScene(scene); // Place the scene in the stage.
			primaryStage.show(); // Display the stage.
			
			// Connect to database
		    initializeDB();
		    
		    // Set the actions of the buttons.
		    btView.setOnAction(e -> view());
		    btInsert.setOnAction(e -> insert());
		    btUpdate.setOnAction(e -> update());
		    btClear.setOnAction(e -> clear());    
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}

	private void initializeDB() 
	{
		try 
		{
			// Connect to the database.
			Connection conn = DriverManager.getConnection ("jdbc:mysql://localhost/javabook", "scott", "tiger");
			System.out.println("Database connected\n");
			
			// Create a statement.
			stmt = conn.createStatement();
		} 
		catch(Exception ex)
		{
			lblStatus.setText("Connection Failed: " + ex);
		}
	}
	
	// Views records by ID's.
	private void view() 
	{
		// Build the SQL select statement.
		String query = "SELECT * FROM Staff WHERE ID = " + "'" + tfID.getText().trim() + "'";
		
		try 
		{
			// Execute the query.
			ResultSet rs = stmt.executeQuery(query);
			loadToTextField(rs);
		}
		catch(SQLException ex)
		{
			lblStatus.setText("Select failed: " + ex);
		}
	}
	
	// Load the record into the text fields.
	private void loadToTextField(ResultSet rs) throws SQLException
	{
		if (rs.next()) 
		{
			tfLName.setText(rs.getString(2));
		    tfFName.setText(rs.getString(3));
		    tfMInital.setText(rs.getString(4));
		    tfAddress.setText(rs.getString(5));
		    tfCity.setText(rs.getString(6));
		    tfState.setText(rs.getString(7));
		    tfPhone.setText(rs.getString(8));
		    lblStatus.setText("Record found.");
		}
		else 
		{
			lblStatus.setText("Record not found.");
		}
	}
	
	// Creates a new record.
	private void insert() 
	{
		// Build the SQL insert statement. 
		String insertStmt = "INSERT INTO Staff(ID, LastName, FirstName, mi, Address, " + " City, State, Telephone) VALUES('" + 
				tfID.getText().trim() + "','" + tfLName.getText().trim() + "','" + tfFName.getText().trim() + "','" + 
				tfMInital.getText().trim() + "','" + tfAddress.getText().trim() + "','" + tfCity.getText().trim() + "','" + 
				tfState.getText().trim() + "','" + tfPhone.getText().trim() + "');";
	
		try 
		{
			stmt.executeUpdate(insertStmt);
			lblStatus.setText("Record inserted.");
		}
		catch (SQLException ex)
		{
			lblStatus.setText("Insertion failed: " + ex);
		}
		
		
	}
	
	// Update the record.
	private void update() 
	{
		// Build the SQL update statement.
		String updateStmt = "UPDATE Staff " + "SET LastName = '" + tfLName.getText().trim() + "'," + "FirstName = '" + tfFName.getText().trim() + "'," +
				"mi = '" + tfMInital.getText().trim() + "'," + "Address = '" + tfAddress.getText().trim() + "'," + "City = '" + tfCity.getText().trim() + "'," + 
				"State = '" + tfState.getText().trim() + "'," + "Telephone = '" + tfPhone.getText().trim() + "' " +"WHERE ID = '" + tfID.getText().trim() + "'";
		try 
		{
			stmt.executeUpdate(updateStmt);
			lblStatus.setText("Record updated.");
		}
		catch(SQLException ex)
		{
			lblStatus.setText("Update failed: " + ex);
		}
	}
	
	// Clear the text fields.
	private void clear()
	{
		tfID.setText(null);
		tfLName.setText(null);
		tfFName.setText(null);
		tfMInital.setText(null);
		tfAddress.setText(null);
		tfCity.setText(null);
		tfState.setText(null);
		tfPhone.setText(null);
	}

	// Launch the program.
	public static void main(String[] args) 
	{
		launch(args);
	}
}