package application;
	
import java.io.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class Split extends Application 
{
	
	// Create text fields for the file name and the amount of files to spilt it into.
	protected TextField tfFileName = new TextField();
	protected TextField tfNumOfFiles = new TextField();
	
	@Override
	public void start(Stage primaryStage) 
	{
		try 
		{
			// Create a label.
			Label lblText = new Label();
			lblText.setText("If you split a file named temp.txt into 3 smaller files,\n" +"the three smaller files are temp.txt.1, temp.txt.2, and temp.txt.3.");
			
			// Create a grid pane for labels and text fields.
			GridPane paneForInfo = new GridPane();
			paneForInfo.setPadding(new Insets(15, 15, 15, 0));
			paneForInfo.setHgap(5);
			paneForInfo.add(new Label("Enter a file:"), 0, 0);
			paneForInfo.add(tfFileName, 1, 0);
			paneForInfo.add(new Label("Specify the number of smaller files:"), 0, 1);
			paneForInfo.add(tfNumOfFiles, 1, 1);
			
			// Create the start button.
			Button btStart = new Button("Start");
			
			// Create a border pane and place the node inside it.
			BorderPane pane = new BorderPane();
			pane.setTop(lblText);
			pane.setCenter(paneForInfo);
			pane.setBottom(btStart);
			pane.setAlignment(btStart, Pos.CENTER);
			
			// Create and register the handle.
			btStart.setOnAction(e -> start());
			
			// Create the scene and place it in the stage.
			Scene scene = new Scene(pane,400,200);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Exercise_17_11"); // Set the title of the stage.
			primaryStage.setScene(scene); // Place the scene in the stage.
			primaryStage.show(); // Display the stage.
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void start() 
	{
		
		// Get the number of pieces.
		int numberOfFiles = Integer.parseInt(tfNumOfFiles.getText());

		// Create an array of random access files to hold the pieces.
		RandomAccessFile[] splits = new RandomAccessFile[numberOfFiles];
		
		// Create a random access file.
		try (RandomAccessFile inout = new RandomAccessFile(tfFileName.getText(), "r");) 
		{
			for (int i = 0; i < splits.length; i++) 
			{
				splits[i] = new RandomAccessFile(tfFileName.getText() + "." + (i + 1), "rw");
			}
			int size = Math.round(inout.length() / numberOfFiles);
			int count = 0; // Counts pieces read.
			byte[] b;

			for (int i = 0; i < numberOfFiles - 1; i++) 
			{
				inout.seek(count * size);
				b = new byte[size];
				inout.read(b);
				splits[i].write(b);
				count++;
			}
			
			inout.seek(count * size);
			b = new byte[(int)inout.length() - (count * size)];
			inout.read(b);
			splits[numberOfFiles - 1].write(b);
		}
		catch (IOException ex) 
		{
			
		}
	}
	
	public static void main(String[] args) 
	{
		launch(args);
	}
}
